//
//  ViewController.swift
//  seatselector
//
//  Created by kishore on 17/02/20.
//  Copyright © 2020 kishore. All rights reserved.
//

import UIKit

class ViewController: UIViewController,SeatSelectorDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let map:String =    "AAAAA_DAAAA/" +
                                "UAAAA_DAAAA/" +
                                "UUUUU_DAAAA/" +
                                "UAAAA_AAAAA/" +
                                "AAAAA_AAAAA/";
            
            let seats = SeatSelector()
            seats.frame = CGRect(x: 0, y: 50, width: self.view.frame.size.width, height: 150)
        seats.setSeatSize(size: CGSize(width: 10, height: 10))
            seats.setAvailableImage(UIImage(named: "A")!,
                andUnavailableImage:UIImage(named: "U")!,
                andDisabledImage:   UIImage(named: "D")!,
                andSelectedImage:   UIImage(named: "S")!)
            seats.layout_type = "Normal"
            seats.setMap(map)
            seats.seat_price = 10.0
            seats.selected_seat_limit = 3
            seats.seatSelectorDelegate = self
            //self.view.addSubview(seats)
            
            let map2:String =   "_DDDDDD_DDDDDD_DDDDDDDD_/" +
                                "_AAAAAA_AAAAAA_DUUUAAAA_/" +
                                "________________________/" +
                                "_AAAAAUUAAAUAAAAUAAAAAAA/" +
                                "_UAAUUUUUUUUUUUUUUUAAAAA/" +
                                "_AAAAAAAAAAAUUUUUUUAAAAA/" +
                                "_AAAAAAAAUAAAAUUUUAAAAAA/" +
                                "_AAAAAUUUAUAUAUAUUUAAAAA/"
            
            let seats2 = SeatSelector()
            seats2.frame = CGRect(x: 0, y: 250, width: self.view.frame.size.width, height: 600)
        seats2.setSeatSize(size: CGSize(width: 30, height: 30))
            seats2.setAvailableImage(   UIImage(named: "A")!,
                andUnavailableImage:    UIImage(named: "U")!,
                andDisabledImage:       UIImage(named: "D")!,
                andSelectedImage:       UIImage(named: "S")!)
            seats2.layout_type = "Normal"
            seats2.setMap(map2)
            seats2.seat_price           = 5.0
            seats2.selected_seat_limit  = 5
            seats2.seatSelectorDelegate = self
            seats2.maximumZoomScale         = 5.0
            seats2.minimumZoomScale         = 0.05
            self.view.addSubview(seats2)
            
            
        }
        
    func seatSelected(seat: ZSeat) {
            //print("Seat at row: \(seat.row) and column: \(seat.column)\n")
        }
        
    func getSelectedSeats(seats: NSMutableArray) {
            var total:Float = 0.0;
            for i in 0..<seats.count {
                let seat:ZSeat  = seats.object(at: i) as! ZSeat
                print("Seat at row: \(seat.row) and column: \(seat.column)\n")
                total += seat.price
            }
            print("----- Total -----\n")
            print("----- \(total) -----\n")
        }

        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }

    }




